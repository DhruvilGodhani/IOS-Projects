//
//  CoreDataManager.swift
//  CoreDataDemo2
//
//  Created by ADMIN on 24/09/24.
//

import Foundation
import UIKit
final class CoreDataManager{
    static func addToCoreData(userData: UserModel){
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else {return}
        
    }
}
