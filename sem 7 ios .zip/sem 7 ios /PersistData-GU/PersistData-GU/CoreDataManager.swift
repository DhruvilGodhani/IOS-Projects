//
//  CoreDataManager.swift
//  PersistData-GU
//
//  Created by Jaimin Raval on 23/09/24.
//

import Foundation
